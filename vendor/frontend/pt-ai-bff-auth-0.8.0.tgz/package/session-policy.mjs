// Session policy is protocol data. Applications still own principals and Session rows.
export const SESSION_POLICY_LIMITS = Object.freeze({
  ordinaryIdle: 36000,
  ordinaryMax: 86400,
  rememberIdle: 2592000,
  rememberMax: 7776000,
  managementIdle: 3600,
  statusCache: 60000,
});
export class SessionPolicyError extends Error {
  constructor(code, status = 401) {
    super(code);
    this.code = code;
    this.status = status;
  }
}
export function loadSessionPolicyV1(env = {}, prefix = "", management = false) {
  const mode = env[`${prefix}SESSION_POLICY_V1_MODE`] ?? "legacy";
  if (!["legacy", "shadow", "enforce"].includes(mode))
    throw new SessionPolicyError("auth_configuration_invalid", 503);
  const read = (name, fallback, max) => {
    const raw = env[prefix + name];
    const n = raw === undefined || raw === "" ? fallback : Number(raw);
    if (!Number.isInteger(n) || n < 60 || n > max)
      throw new SessionPolicyError("auth_configuration_invalid", 503);
    return n;
  };
  const idleSeconds = read(
    "SESSION_IDLE_SECONDS",
    management ? 3600 : 36000,
    management ? 3600 : 86400,
  );
  const maxSeconds = read(
    "SESSION_MAX_SECONDS",
    86400,
    mode !== "enforce" && !management ? 7776000 : 86400,
  );
  const rememberIdleSeconds = read(
    "SESSION_REMEMBER_IDLE_SECONDS",
    management ? 3600 : 2592000,
    management ? 3600 : 7776000,
  );
  const rememberMaxSeconds = read(
    "SESSION_REMEMBER_MAX_SECONDS",
    management ? 86400 : 7776000,
    management ? 86400 : 7776000,
  );
  if (idleSeconds > maxSeconds || rememberIdleSeconds > rememberMaxSeconds)
    throw new SessionPolicyError("auth_configuration_invalid", 503);
  return {
    mode,
    management,
    idleSeconds,
    maxSeconds,
    rememberIdleSeconds,
    rememberMaxSeconds,
  };
}
export function verifiedSessionPolicy(payload, now = Date.now()) {
  const p = payload.pt_session,
    n = Math.floor(now / 1000);
  if (
    !p ||
    p.v !== 1 ||
    !["session", "remember"].includes(p.mode) ||
    typeof payload.sid !== "string" ||
    !payload.sid ||
    payload.sid.length > 256 ||
    !Number.isSafeInteger(p.cycle_started_at) ||
    !Number.isSafeInteger(p.cycle_expires_at) ||
    p.cycle_started_at < 0 ||
    p.cycle_started_at > n + 60 ||
    p.cycle_expires_at <= p.cycle_started_at ||
    p.cycle_expires_at <= n ||
    p.cycle_expires_at - p.cycle_started_at >
      (p.mode === "remember" ? 7776000 : 86400)
  )
    throw new SessionPolicyError("auth_session_policy_invalid");
  return {
    mode: p.mode,
    issuerSessionId: payload.sid,
    cycleStartedAt: p.cycle_started_at,
    cycleExpiresAt: p.cycle_expires_at,
  };
}
export function requireFreshAuthentication(payload, tx, now = Date.now()) {
  if (!tx.requireFreshAuth) return;
  const requested = Date.parse(tx.reauthRequestedAt) / 1000;
  if (
    !Number.isFinite(requested) ||
    !Number.isSafeInteger(payload.auth_time) ||
    payload.auth_time < requested - 60 ||
    payload.auth_time > Math.floor(now / 1000) + 60
  )
    throw new SessionPolicyError("auth_reauthentication_required");
  if (tx.expectedSubject && payload.sub !== tx.expectedSubject)
    throw new SessionPolicyError("auth_account_mismatch", 409);
}
export function sessionTerms(policy, identity, now = Date.now()) {
  const p = identity.sessionPolicy;
  if (!p) throw new SessionPolicyError("auth_session_policy_invalid");
  const remember = p.mode === "remember";
  const max = remember ? policy.rememberMaxSeconds : policy.maxSeconds;
  const expiresAt = new Date(
    Math.min(
      now + max * 1000,
      p.cycleExpiresAt * 1000,
      ...(policy.management ? [identity.authTime * 1000 + 86400000] : []),
    ),
  );
  if (!Number.isFinite(expiresAt.getTime()) || expiresAt.getTime() <= now)
    throw new SessionPolicyError("auth_session_policy_invalid");
  return {
    expiresAt,
    persistenceMode: p.mode,
    idleSeconds: remember ? policy.rememberIdleSeconds : policy.idleSeconds,
  };
}
export function sessionIdleSeconds(row, policy, legacyIdleSeconds) {
  if (Number(row.session_policy_version) !== 1) return legacyIdleSeconds;
  return row.persistence_mode === "remember"
    ? policy.rememberIdleSeconds
    : policy.idleSeconds;
}

// One client instance per configured application runtime. No user credentials retained here.
export function createIdentitySessionChecker({
  issuer,
  clientId,
  clientSecret,
  fetchImpl = fetch,
  now = Date.now,
}) {
  const base = issuer.replace(/\/$/, "");
  const cache = new Map();
  let token = null;
  let pendingToken = null;
  async function serviceToken(signal) {
    if (token && token.until > now()) return token.value;
    if (!pendingToken)
      pendingToken = (async () => {
        const started = now();
        const r = await fetchImpl(base + "/protocol/openid-connect/token", {
          method: "POST",
          signal,
          headers: { "content-type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            grant_type: "client_credentials",
            client_id: clientId,
            client_secret: clientSecret,
          }),
        });
        if (!r.ok)
          throw new SessionPolicyError("auth_identity_unavailable", 503);
        const b = await r.json();
        if (
          typeof b.access_token !== "string" ||
          !Number.isFinite(b.expires_in) ||
          b.expires_in <= 0
        )
          throw new SessionPolicyError("auth_identity_unavailable", 503);
        token = {
          value: b.access_token,
          until: started + Math.max(0, b.expires_in - 30) * 1000,
        };
        return token.value;
      })().finally(() => {
        pendingToken = null;
      });
    return pendingToken;
  }
  return async function check({
    sid,
    subject,
    activity = false,
    fresh = false,
  }) {
    if (!issuer || !clientId || !clientSecret || !sid || !subject)
      throw new SessionPolicyError("auth_identity_unavailable", 503);
    const key = JSON.stringify([sid, subject]);
    const started = now(),
      hit = cache.get(key);
    if (!activity && !fresh && hit && hit.until > started) return hit.result;
    const signal = AbortSignal.timeout(3000);
    try {
      const bearer = await serviceToken(signal);
      const r = await fetchImpl(base + "/pt-ai/session-status", {
        method: "POST",
        signal,
        headers: {
          authorization: "Bearer " + bearer,
          "content-type": "application/json",
        },
        body: JSON.stringify({ sid, subject, activity }),
      });
      if (!r.ok) {
        if (r.status === 401) token = null;
        throw new SessionPolicyError("auth_identity_unavailable", 503);
      }
      const b = await r.json();
      if (b.active === false) {
        cache.delete(key);
        return { active: false };
      }
      if (
        b.active !== true ||
        !Number.isSafeInteger(b.cycle_expires_at) ||
        b.cycle_expires_at * 1000 <= now()
      )
        throw new SessionPolicyError("auth_identity_unavailable", 503);
      const result = { active: true, cycleExpiresAt: b.cycle_expires_at };
      // Bound memory without extending the authentication cache's time window.
      for (const [k, v] of cache) if (v.until <= started) cache.delete(k);
      if (cache.size >= 10000) cache.delete(cache.keys().next().value);
      cache.set(key, {
        until: Math.min(started + 60000, b.cycle_expires_at * 1000),
        result,
      });
      return result;
    } catch (error) {
      cache.delete(key);
      if (error instanceof SessionPolicyError) throw error;
      throw new SessionPolicyError("auth_identity_unavailable", 503);
    }
  };
}
