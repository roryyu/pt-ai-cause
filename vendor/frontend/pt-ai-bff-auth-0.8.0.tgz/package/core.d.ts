import type {
  SessionPolicyConfig,
  VerifiedSessionPolicy,
  IdentitySessionInput,
} from "./session-policy.mjs";
export const AUTH_LIMITS: Readonly<{
  discovery: 3000;
  jwks: 3000;
  access: 3000;
  token: 10000;
  callback: 20000;
  transaction: 600;
}>;
export const CONTEXT_HEADER: "x-pt-session-context";
export class AuthError extends Error {
  code: string;
  stage: string;
  status: number;
  statusCode: number;
  retryable: boolean;
  constructor(
    code: string,
    stage?: string,
    status?: number,
    retryable?: boolean,
  );
}
export interface AuthRequest {
  url: URL;
  method: string;
  headers: Headers;
  correlationId: string;
  form?: Readonly<Record<string, string>>;
}
export interface AuthRedirect {
  status: 302 | 303;
  location: string;
  setCookies: string[];
}
export interface Binding {
  createdAt?: string | Date;
  bindingHash: string;
  epoch: string;
  currentContextId: string | null;
}
export interface PendingTransaction {
  stateHash: string;
  bindingHash: string;
  epoch: string;
  intent: "continue" | "switch" | "reauth";
  requireFreshAuth?: boolean;
  reauthRequestedAt?: string | Date | null;
  expectedSubject?: string | null;
  nonce: string;
  verifier: string;
  returnTo: string;
  ttlSeconds: number;
}
export interface ClaimedTransaction {
  stateHash: string;
  bindingHash: string;
  epoch: string;
  claimToken: string;
  nonce: string;
  verifier: string;
  returnTo: string;
  intent: "continue" | "switch" | "reauth";
  requireFreshAuth?: boolean;
  reauthRequestedAt?: string | Date | null;
  expectedSubject?: string | null;
  deadline: number;
}
export interface AuthStore<P, S extends object> {
  expectedSubject?(hash: string): Promise<string | null>;
  getBinding(hash: string): Promise<Binding | null | undefined>;
  createBinding(hash: string): Promise<Binding>;
  createTransaction(input: PendingTransaction): Promise<void>;
  claim(input: {
    stateHash: string;
    bindingHash: string;
  }): Promise<ClaimedTransaction>;
  fail(input: {
    stateHash: string;
    claimToken: string;
    code: string;
  }): Promise<void>;
  finalize(input: {
    transaction: ClaimedTransaction;
    contextId: string;
    proofHash: string;
    prepared: P;
  }): Promise<{
    contextId: string;
    maxAgeSeconds: number;
    persistenceMode?: "session" | "remember";
  }>;
  cancel(input: {
    bindingHash: string;
    expectedContext: string | null;
  }): Promise<{ epoch: string }>;
  resolveSession(input: {
    bindingHash: string;
    contextId: string;
    proofHash: string;
  }): Promise<
    (S & { contextId: string; bindingHash: string; sessionRef: string; sessionPolicyVersion?: number; identitySession?: {issuer: string; sid: string; subject: string} }) | null
  >;
}
export interface BrowserAuthConfig {
  sessionPolicy?: SessionPolicyConfig;
  appId: "access" | "portal" | "foundation" | "creative" | "cause";
  publicOrigin: string;
  issuer: string;
  internalIssuer?: string;
  clientId: string;
  callbackPath: string;
  fallbackReturnTo?: string;
  errorPath?: string;
  clientAuthentication?: {
    method: "none" | "client_secret_post" | "client_secret_basic";
    secret?: string;
  };
}
export function createBrowserAuthCore<P, S extends object>(input: {
  config: BrowserAuthConfig;
  store: AuthStore<P, S>;
  application: {
    checkIdentitySession?(
      input: IdentitySessionInput,
    ): Promise<{ active: boolean; cycleExpiresAt?: number }>;
    prepareSession(input: {
      identity: {
        issuer: string;
        subject: string;
        authTime?: number;
        sessionPolicy?: VerifiedSessionPolicy;
      };
      tokens: {
        idToken: string;
        accessToken?: string;
        refreshToken?: string;
        expiresIn?: number;
      };
      signal: AbortSignal;
    }): Promise<P>;
  };
  fetchImpl?: typeof fetch;
  onFailure?: (event: Record<string, unknown>) => void;
}): {
  touchIdentity(request: AuthRequest): Promise<void>;
  begin(request: AuthRequest): Promise<AuthRedirect>;
  callback(request: AuthRequest): Promise<AuthRedirect>;
  logout(request: AuthRequest): Promise<void>;
  switchAccount(request: AuthRequest): Promise<AuthRedirect>;
  resolve(request: AuthRequest): ReturnType<AuthStore<P, S>["resolveSession"]>;
  failure(
    request: AuthRequest,
    error: unknown,
    returnTo?: string,
  ): AuthRedirect;
  clearObservedProofCookies(request: AuthRequest): string[];
  names: { binding: string; proof(context: string): string };
  bootstrap(
    request: AuthRequest,
  ): Promise<(Binding & { setCookies: string[] }) | null>;
};
export function randomSecret(bytes?: number): string;
export function secretHash(value: string): Promise<string>;
export function parseAuthCookies(header?: string): Map<string, string>;
export function authCookieNames(
  appId: string,
  secure: boolean,
): { binding: string; proof(context: string): string };
export function authCookie(
  name: string,
  value: string,
  secure: boolean,
  maxAge?: number,
): string;
export function safeAuthReturnTo(value: unknown, fallback?: string): string;
export function requireAuthMutation(
  request: AuthRequest,
  publicOrigin: string,
): string | null;
export function requireSessionContext(
  headers: Headers,
  contextId: string,
  formContext?: string,
): void;
export function authRecoveryCode(error: unknown): string;
export function authFailureLog(
  appId: string,
  request: AuthRequest,
  error: unknown,
  elapsedMs: number,
): Record<string, unknown>;

export function verifyOidcIdentityToken(input: {
  token: string;
  jwksUrl: string | URL;
  issuer: string;
  clientId: string;
  nonce?: string;
  expectedSubject?: string;
  deadline?: number;
  fetchImpl?: typeof fetch;
}): Promise<{
  iss: string;
  sub: string;
  auth_time?: number;
  [claim: string]: unknown;
}>;
