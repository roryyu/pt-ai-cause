import {
  createHash,
  randomBytes,
  randomUUID,
  timingSafeEqual,
  webcrypto,
} from "node:crypto";

const encoder = new TextEncoder();

export function randomToken(bytes = 32) {
  return randomBytes(bytes).toString("base64url");
}

export function opaqueHash(value) {
  return createHash("sha256").update(value).digest("hex");
}

export function safeEqual(left, right) {
  const a = Buffer.from(String(left || ""));
  const b = Buffer.from(String(right || ""));
  return a.length === b.length && timingSafeEqual(a, b);
}

export function parseCookies(header = "") {
  const cookies = {};
  for (const part of header.split(";")) {
    const index = part.indexOf("=");
    if (index < 0) continue;
    const name = part.slice(0, index).trim();
    if (!name) continue;
    cookies[name] = decodeURIComponent(part.slice(index + 1).trim());
  }
  return cookies;
}

export function sessionCookie(name, value, { maxAgeSeconds = 28_800, secure = false } = {}) {
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${Math.max(0, maxAgeSeconds)}`,
  ];
  if (secure) parts.push("Secure");
  return parts.join("; ");
}

export function clearCookie(name, { secure = false } = {}) {
  return sessionCookie(name, "", { maxAgeSeconds: 0, secure });
}

export function sendJson(response, status, body, headers = {}) {
  const payload = JSON.stringify(body);
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(payload),
    ...headers,
  });
  response.end(payload);
}

export function sendText(response, status, body, contentType = "text/plain; charset=utf-8", headers = {}) {
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-type": contentType,
    "content-length": Buffer.byteLength(body),
    ...headers,
  });
  response.end(body);
}

export function redirect(response, location, headers = {}, status = 302) {
  response.writeHead(status, { location, "cache-control": "no-store", ...headers });
  response.end();
}

export async function readJson(request, { limit = 64 * 1024 } = {}) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw httpError(413, "payload_too_large", "请求内容过大");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw httpError(400, "invalid_json", "请求内容不是有效的 JSON");
  }
}

export function httpError(status, code, message, details) {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}

export function handleHttpError(response, error, correlationId = randomUUID()) {
  const status = Number.isInteger(error?.status) ? error.status : 500;
  const code = error?.code || "internal_error";
  if (status >= 500) console.error(`[${correlationId}]`, error);
  sendJson(response, status, {
    error: { code, message: status >= 500 ? "服务暂时不可用，请稍后重试" : error.message, correlationId },
  });
}

export function requestContext(request) {
  const incoming = request.headers["x-correlation-id"];
  const correlationId = typeof incoming === "string" && /^[a-zA-Z0-9_.:-]{8,128}$/.test(incoming)
    ? incoming
    : randomUUID();
  return { correlationId };
}

export function normalizeReturnTo(value, fallback = "/", { blockedPrefixes = ["/auth/"], maxLength = 2_048 } = {}) {
  if (
    typeof value !== "string" ||
    value.length > maxLength ||
    !value.startsWith("/") ||
    /[\\\u0000-\u001f\u007f]/.test(value) ||
    /^\/(?:%2f|%5c)/i.test(value)
  ) return fallback;
  try {
    const base = new URL("http://return-to.invalid/");
    const target = new URL(value, base);
    if (target.origin !== base.origin) return fallback;
    const normalized = `${target.pathname}${target.search}${target.hash}`;
    const normalizedPath = target.pathname.toLowerCase();
    if (blockedPrefixes.some((prefix) => {
      const candidate = String(prefix || "").toLowerCase();
      return candidate && (normalizedPath === candidate.replace(/\/$/, "") || normalizedPath.startsWith(candidate));
    })) return fallback;
    return normalized;
  } catch {
    return fallback;
  }
}

export function requireSameOriginMutation(request, expectedOrigin, { sessionCookieName } = {}) {
  const method = String(request?.method || "GET").toUpperCase();
  if (["GET", "HEAD", "OPTIONS"].includes(method)) return;
  const cookieHeader = requestHeader(request, "cookie") || "";
  if (sessionCookieName && !parseCookies(cookieHeader)[sessionCookieName]) return;

  const fetchSite = String(requestHeader(request, "sec-fetch-site") || "").toLowerCase();
  if (fetchSite && !["same-origin", "none"].includes(fetchSite)) {
    throw httpError(403, "csrf_origin_invalid", "请求必须来自当前应用");
  }
  const origin = requestHeader(request, "origin");
  if (!origin) throw httpError(403, "csrf_origin_required", "状态变更请求缺少同源校验");
  let actual;
  let expected;
  try {
    actual = new URL(origin).origin;
    expected = new URL(expectedOrigin).origin;
  } catch {
    throw httpError(403, "csrf_origin_invalid", "请求来源无效");
  }
  if (actual !== expected) throw httpError(403, "csrf_origin_invalid", "请求必须来自当前应用");
}

/**
 * Discovers the provider's browser-facing end-session endpoint and builds a
 * logout URL without accepting a user-controlled return target. Applications
 * must supply their own fixed post-logout entry URL.
 */
export async function buildOidcEndSessionUrl({
  publicIssuer,
  internalIssuer = publicIssuer,
  clientId,
  postLogoutRedirectUri,
  fetchImpl = globalThis.fetch,
  timeoutMs = 3_000,
} = {}) {
  const publicBase = validatedIssuer(publicIssuer, "publicIssuer");
  const internalBase = validatedIssuer(internalIssuer, "internalIssuer");
  if (typeof clientId !== "string" || !clientId.trim()) {
    throw httpError(500, "oidc_config_invalid", "OIDC client configuration is invalid");
  }
  const postLogout = validatedExternalUrl(postLogoutRedirectUri, "postLogoutRedirectUri");
  if (typeof fetchImpl !== "function") {
    throw httpError(500, "oidc_config_invalid", "OIDC discovery transport is unavailable");
  }

  let response;
  try {
    response = await fetchImpl(`${internalBase}/.well-known/openid-configuration`, {
      headers: { accept: "application/json" },
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch {
    throw httpError(503, "oidc_discovery_unavailable", "身份服务暂时不可用");
  }
  if (!response?.ok) {
    throw httpError(503, "oidc_discovery_unavailable", "身份服务暂时不可用");
  }
  let discovery;
  try {
    discovery = await response.json();
  } catch {
    throw httpError(503, "oidc_discovery_invalid", "身份服务配置无效");
  }
  if (normalizedUrlString(discovery?.issuer) !== publicBase) {
    throw httpError(503, "oidc_discovery_invalid", "身份服务配置无效");
  }
  const endSession = validatedExternalUrl(discovery?.end_session_endpoint, "end_session_endpoint");
  const issuerUrl = new URL(publicBase);
  const endSessionUrl = new URL(endSession);
  const issuerPrefix = issuerUrl.pathname.endsWith("/") ? issuerUrl.pathname : `${issuerUrl.pathname}/`;
  if (endSessionUrl.origin !== issuerUrl.origin || !endSessionUrl.pathname.startsWith(issuerPrefix)) {
    throw httpError(503, "oidc_discovery_invalid", "身份服务配置无效");
  }
  endSessionUrl.searchParams.set("client_id", clientId);
  endSessionUrl.searchParams.set("post_logout_redirect_uri", postLogout);
  return endSessionUrl.toString();
}

function requestHeader(request, name) {
  if (typeof request?.headers?.get === "function") return request.headers.get(name);
  const value = request?.headers?.[name] ?? request?.headers?.[name.toLowerCase()];
  return Array.isArray(value) ? value[0] : value;
}

function validatedIssuer(value, field) {
  const url = new URL(validatedExternalUrl(value, field));
  if (url.pathname === "/") {
    throw httpError(500, "oidc_config_invalid", "OIDC issuer configuration is invalid");
  }
  return url.toString().replace(/\/$/, "");
}

function validatedExternalUrl(value, field) {
  if (typeof value !== "string" || !value) {
    throw httpError(503, "oidc_discovery_invalid", "身份服务配置无效");
  }
  let url;
  try {
    url = new URL(value);
  } catch {
    throw httpError(503, "oidc_discovery_invalid", "身份服务配置无效");
  }
  if (
    !["http:", "https:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.hash
  ) {
    throw httpError(503, "oidc_discovery_invalid", "身份服务配置无效");
  }
  return url.toString();
}

function normalizedUrlString(value) {
  try {
    return new URL(String(value || "")).toString().replace(/\/$/, "");
  } catch {
    return "";
  }
}
