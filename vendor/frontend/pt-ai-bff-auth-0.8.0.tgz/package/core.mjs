import {
  verifiedSessionPolicy,
  requireFreshAuthentication,
  SessionPolicyError,
} from "./session-policy.mjs";
import { createRemoteJWKSet, jwtVerify, customFetch } from "jose";

export const AUTH_LIMITS = Object.freeze({
  discovery: 3000,
  jwks: 3000,
  access: 3000,
  token: 10000,
  callback: 20000,
  transaction: 600,
});
export const CONTEXT_HEADER = "x-pt-session-context";
export class AuthError extends Error {
  constructor(code, stage = "transaction", status = 400, retryable = false) {
    super(code);
    this.name = "AuthError";
    Object.assign(this, { code, stage, status, statusCode: status, retryable });
  }
}
export function randomSecret(bytes = 32) {
  return btoa(
    String.fromCharCode(...crypto.getRandomValues(new Uint8Array(bytes))),
  )
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replace(/=+$/, "");
}
export async function secretHash(value) {
  return Array.from(
    new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)),
    ),
    (b) => b.toString(16).padStart(2, "0"),
  ).join("");
}
export function parseAuthCookies(header = "") {
  const cookies = new Map();
  for (const part of header.split(";")) {
    const index = part.indexOf("=");
    if (index < 1) continue;
    const name = part.slice(0, index).trim();
    if (cookies.has(name)) throw new AuthError("oidc_transaction_invalid");
    try {
      cookies.set(name, decodeURIComponent(part.slice(index + 1).trim()));
    } catch {
      throw new AuthError("oidc_transaction_invalid");
    }
  }
  return cookies;
}
export function authCookieNames(appId, secure) {
  if (!["access", "portal", "foundation", "creative", "cause"].includes(appId))
    throw new AuthError("auth_configuration_invalid", "configuration", 503);
  const prefix = `${secure ? "__Host-" : ""}pt_${appId}_`;
  return {
    binding: `${prefix}binding`,
    proof: (context) => `${prefix}proof_${context}`,
  };
}
export function authCookie(name, value, secure, maxAge) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax${secure ? "; Secure" : ""}${maxAge === undefined ? "" : `; Max-Age=${Math.max(0, Math.floor(maxAge))}`}`;
}
export function safeAuthReturnTo(value, fallback = "/") {
  if (
    typeof value !== "string" ||
    value.length > 1024 ||
    !value.startsWith("/") ||
    value.startsWith("//") ||
    /[\\\x00-\x1f\x7f]/.test(value)
  )
    return fallback;
  let path;
  try {
    path = decodeURIComponent(
      new URL(value, "https://return.invalid").pathname,
    );
  } catch {
    return fallback;
  }
  if (
    path.startsWith("//") ||
    /[\\\x00-\x1f\x7f]/.test(path) ||
    /^(?:\/api(?:\/v1)?)?\/auth(?:\/|$)/.test(path) ||
    /^\/login(?:\/|$)/.test(path)
  )
    return fallback;
  return value;
}
export function requireAuthMutation(request, publicOrigin) {
  if (request.method !== "POST")
    throw new AuthError("auth_method_invalid", "transaction", 405);
  if (request.headers.get("origin") !== publicOrigin)
    throw new AuthError("auth_origin_invalid", "transaction", 403);
  const header = request.headers.get(CONTEXT_HEADER),
    field = request.form?._pt_session_context;
  if (header !== null && field !== undefined && header !== field)
    throw new AuthError("session_context_changed", "transaction", 409);
  const value = header ?? field;
  if (value === "none") return null;
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{22}$/.test(value))
    throw new AuthError("session_context_changed", "transaction", 409);
  return value;
}
export function requireSessionContext(headers, contextId, formContext) {
  const value = headers.get(CONTEXT_HEADER) ?? formContext;
  if (
    !contextId ||
    value !== contextId ||
    (formContext !== undefined && formContext !== value)
  )
    throw new AuthError("session_context_changed", "transaction", 409);
}
export function authRecoveryCode(error) {
  const code = error?.code || "";
  if (code === "auth_identity_unavailable") return "identity_unavailable";
  if (code === "auth_account_mismatch") return "session_context_changed";
  if (
    code === "auth_reauthentication_required" ||
    code === "auth_session_policy_invalid"
  )
    return "oidc_transaction_invalid";
  if (
    [
      "account_disabled",
      "entry_entitlement_required",
      "native_role_required",
      "access_unavailable",
    ].includes(code)
  )
    return code;
  if (code === "oidc_denied") return "oidc_denied";
  if (code === "oidc_verification_failed")
    return "identity_verification_failed";
  if (["oidc_discovery_unavailable", "oidc_jwks_unavailable"].includes(code))
    return "identity_unavailable";
  if (code === "oidc_transaction_in_progress") return "login_in_progress";
  if (
    [
      "oidc_transaction_cancelled",
      "oidc_transaction_superseded",
      "session_context_changed",
    ].includes(code)
  )
    return "login_state_changed";
  if (["oidc_transaction_invalid", "oidc_transaction_expired"].includes(code))
    return "oidc_transaction_expired";
  return "login_failed";
}
export function authFailureLog(appId, request, error, elapsedMs) {
  return {
    event: "authentication_route_failed",
    appId,
    correlationId: request.correlationId,
    stage: error instanceof AuthError ? error.stage : "persistence",
    code: error instanceof AuthError ? error.code : "unexpected_auth_error",
    elapsedMs,
    retryable: error instanceof AuthError && error.retryable,
  };
}

async function withinSignal(operation, signal) {
  signal.throwIfAborted();
  let listener;
  const aborted = new Promise((_, reject) => {
    listener = () =>
      reject(new AuthError("access_unavailable", "access", 503, true));
    signal.addEventListener("abort", listener, { once: true });
  });
  try {
    return await Promise.race([operation, aborted]);
  } finally {
    signal.removeEventListener("abort", listener);
  }
}

export async function verifyOidcIdentityToken({
  token,
  jwksUrl,
  issuer,
  clientId,
  nonce,
  expectedSubject,
  deadline = Date.now() + 3000,
  fetchImpl = fetch,
}) {
  const jwks = createRemoteJWKSet(new URL(jwksUrl), {
    timeoutDuration: Math.max(
      1,
      Math.min(AUTH_LIMITS.jwks, deadline - Date.now()),
    ),
    [customFetch]: fetchImpl,
  });
  let payload;
  try {
    ({ payload } = await jwtVerify(token, jwks, {
      issuer: issuer,
      audience: clientId,
      algorithms: ["RS256"],
      requiredClaims: [
        "exp",
        "iat",
        "sub",
        ...(nonce === undefined ? [] : ["nonce"]),
      ],
      clockTolerance: 30,
    }));
    if (
      typeof payload.sub !== "string" ||
      !payload.sub.trim() ||
      (expectedSubject !== undefined && payload.sub !== expectedSubject) ||
      (nonce !== undefined && payload.nonce !== nonce) ||
      typeof payload.exp !== "number" ||
      typeof payload.iat !== "number" ||
      payload.iat > Date.now() / 1000 + 30 ||
      (((Array.isArray(payload.aud) && payload.aud.length > 1) ||
        payload.azp !== undefined) &&
        payload.azp !== clientId) ||
      (payload.auth_time !== undefined &&
        (typeof payload.auth_time !== "number" ||
          payload.auth_time > Date.now() / 1000 + 30))
    )
      throw new Error("claims");
  } catch (error) {
    const unavailable =
      error?.code === "ERR_JWKS_TIMEOUT" ||
      error?.code === "ERR_JOSE_GENERIC" ||
      (error instanceof TypeError && !error.code);
    throw new AuthError(
      unavailable ? "oidc_jwks_unavailable" : "oidc_verification_failed",
      unavailable ? "jwks" : "verification",
      unavailable ? 503 : 401,
      unavailable,
    );
  }

  return payload;
}

export function createBrowserAuthCore({
  config,
  store,
  application,
  fetchImpl = fetch,
  onFailure = () => {},
}) {
  const publicUrl = new URL(config.publicOrigin),
    issuerUrl = new URL(config.issuer);
  const secure = publicUrl.protocol === "https:";
  if (
    publicUrl.origin !== config.publicOrigin ||
    publicUrl.username ||
    publicUrl.password ||
    issuerUrl.username ||
    issuerUrl.password ||
    issuerUrl.hash ||
    issuerUrl.search ||
    (secure && issuerUrl.protocol !== "https:") ||
    (!secure &&
      !["localhost", "127.0.0.1", "[::1]"].includes(publicUrl.hostname)) ||
    !config.clientId ||
    !config.callbackPath?.startsWith("/")
  ) {
    throw new AuthError("auth_configuration_invalid", "configuration", 503);
  }
  if(config.sessionPolicy?.mode === "enforce" && config.sessionPolicy.management !== ["access","foundation"].includes(config.appId))
    throw new AuthError("auth_configuration_invalid","configuration",503);
  const names = authCookieNames(config.appId, secure);
  const fallback = config.fallbackReturnTo || "/";
  const redirectUri = new URL(config.callbackPath, config.publicOrigin).href;
  if (new URL(redirectUri).origin !== config.publicOrigin)
    throw new AuthError("auth_configuration_invalid", "configuration", 503);
  const endpoint = (value) => {
    const url = new URL(value);
    if (
      url.origin !== issuerUrl.origin ||
      url.username ||
      url.password ||
      url.hash ||
      !url.pathname.startsWith(`${issuerUrl.pathname.replace(/\/$/, "")}/`)
    )
      throw new AuthError("auth_configuration_invalid", "configuration", 503);
    if (config.internalIssuer) {
      const internal = new URL(config.internalIssuer);
      if (
        internal.username ||
        internal.password ||
        internal.search ||
        internal.hash ||
        internal.pathname.replace(/\/$/, "") !==
          issuerUrl.pathname.replace(/\/$/, "")
      )
        throw new AuthError("auth_configuration_invalid", "configuration", 503);
      url.protocol = internal.protocol;
      url.host = internal.host;
    }
    return url;
  };
  const fetchJson = async (url, options, stage, deadline) => {
    const remaining = Math.min(AUTH_LIMITS[stage], deadline - Date.now());
    if (remaining <= 0)
      throw new AuthError(
        stage === "token" ? "oidc_token_timeout" : `oidc_${stage}_unavailable`,
        stage,
        503,
        true,
      );
    let response;
    try {
      response = await fetchImpl(url, {
        ...options,
        redirect: "error",
        signal: AbortSignal.timeout(remaining),
      });
    } catch {
      throw new AuthError(
        stage === "token"
          ? "oidc_token_outcome_unknown"
          : `oidc_${stage}_unavailable`,
        stage,
        503,
        true,
      );
    }
    if (!response.ok)
      throw new AuthError(
        stage === "token"
          ? "oidc_token_exchange_failed"
          : `oidc_${stage}_unavailable`,
        stage,
        stage === "token" ? 401 : 503,
        true,
      );
    try {
      return await response.json();
    } catch {
      throw new AuthError(
        stage === "token"
          ? "oidc_token_exchange_failed"
          : `oidc_${stage}_unavailable`,
        stage,
        503,
      );
    }
  };
  async function discover(deadline) {
    const base = config.internalIssuer || config.issuer;
    const data = await fetchJson(
      `${base.replace(/\/$/, "")}/.well-known/openid-configuration`,
      {},
      "discovery",
      deadline,
    );
    if (data.issuer !== config.issuer)
      throw new AuthError("auth_configuration_invalid", "discovery", 503);
    for (const key of ["authorization_endpoint", "token_endpoint", "jwks_uri"])
      endpoint(data[key]);
    return data;
  }
  async function binding(request, create) {
    const value = parseAuthCookies(request.headers.get("cookie") || "").get(
      names.binding,
    );
    if (value && /^[A-Za-z0-9_-]{43}$/.test(value)) {
      const found = await store.getBinding(await secretHash(value));
      if (found) {
        if (config.sessionPolicy?.mode !== "enforce")
          return { ...found, setCookies: [] };
        const remaining = Math.floor(
          (new Date(found.createdAt).getTime() + 7776000000 - Date.now()) /
            1000,
        );
        if (!Number.isFinite(remaining))
          throw new AuthError("auth_persistence_failed", "persistence", 503);
        if (remaining > 0)
          return {
            ...found,
            setCookies: create
              ? [authCookie(names.binding, value, secure, remaining)]
              : [],
          };
      }
    }
    if (!create) return null;
    const token = randomSecret(),
      bindingHash = await secretHash(token);
    const result = await store.createBinding(bindingHash);
    return {
      ...result,
      setCookies: [
        authCookie(
          names.binding,
          token,
          secure,
          config.sessionPolicy?.mode === "enforce" ? 7776000 : undefined,
        ),
      ],
    };
  }
  function clearObservedProofCookies(request) {
    const prefix = names.proof("");
    return [...parseAuthCookies(request.headers.get("cookie") || "").keys()]
      .filter(
        (name) =>
          name.startsWith(prefix) &&
          /^[A-Za-z0-9_-]{22}$/.test(name.slice(prefix.length)),
      )
      .map((name) => authCookie(name, "", secure, 0));
  }
  async function resolve(request) {
    const bound = await binding(request, false);
    if (!bound?.currentContextId) return null;
    const proof = parseAuthCookies(request.headers.get("cookie") || "").get(
      names.proof(bound.currentContextId),
    );
    if (!proof || !/^[A-Za-z0-9_-]{43}$/.test(proof)) return null;
    const resolved = await store.resolveSession({
      bindingHash: bound.bindingHash,
      contextId: bound.currentContextId,
      proofHash: await secretHash(proof),
    });
    if(resolved && config.sessionPolicy?.mode === "enforce"){
      if(![0,1].includes(resolved.sessionPolicyVersion))throw new AuthError("auth_persistence_failed","persistence",503);
      if(resolved.sessionPolicyVersion===1 && (!resolved.identitySession || typeof resolved.identitySession.sid!=="string" || typeof resolved.identitySession.subject!=="string"))
        throw new AuthError("auth_persistence_failed","persistence",503);
    }
    if (resolved?.identitySession && config.sessionPolicy?.mode === "enforce") {
      if(resolved.identitySession.issuer!==config.issuer)throw new AuthError("session.revoked","session",401);
      await checkIdentity(
        resolved,
        request.method !== "GET" && request.method !== "HEAD",
      );
    }
    return resolved;
  }
  async function checkIdentity(resolved, fresh = false, activity = false) {
    try {
      if (!application.checkIdentitySession)
        throw new SessionPolicyError("auth_identity_unavailable", 503);
      const result = await application.checkIdentitySession({
        ...resolved.identitySession,
        fresh,
        activity,
      });
      if (!result.active)
        throw new AuthError("session.revoked", "session", 401);
      return result;
    } catch (error) {
      if (error instanceof SessionPolicyError)
        throw new AuthError(
          error.code,
          "session",
          error.status,
          error.status === 503,
        );
      throw error;
    }
  }
  async function touchIdentity(request) {
    const resolved = await resolve(request);
    if (!resolved)
      throw new AuthError("auth_reauthentication_required", "session", 401);
    requireSessionContext(request.headers, resolved.contextId);
    if (resolved.identitySession && config.sessionPolicy?.mode === "enforce")
      await checkIdentity(resolved, true, true);
  }
  function failure(request, error, returnTo = fallback) {
    const location = new URL(config.errorPath || "/", config.publicOrigin);
    location.searchParams.set("authError", authRecoveryCode(error));
    location.searchParams.set("returnTo", safeAuthReturnTo(returnTo, fallback));
    return { status: 303, location: location.href, setCookies: [] };
  }
  async function beginWith(request, intent, bound, discovery) {
    const state = randomSecret(),
      verifier = randomSecret(48),
      nonce = randomSecret();
    const stateHash = await secretHash(state);
    const returnTo = safeAuthReturnTo(
      request.form?.returnTo ?? request.url.searchParams.get("returnTo"),
      fallback,
    );
    const digest = new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)),
    );
    const challenge = btoa(String.fromCharCode(...digest))
      .replaceAll("+", "-")
      .replaceAll("/", "_")
      .replace(/=+$/, "");
    const requireFreshAuth =
      config.sessionPolicy?.mode === "enforce" &&
      config.sessionPolicy.management;
    const expectedSubject =
      requireFreshAuth && intent !== "switch"
        ? await store.expectedSubject?.(bound.bindingHash)
        : null;
    const reauthRequestedAt = requireFreshAuth
      ? new Date().toISOString()
      : null;
    await store.createTransaction({
      requireFreshAuth,
      reauthRequestedAt,
      expectedSubject,
      stateHash,
      bindingHash: bound.bindingHash,
      epoch: bound.epoch,
      intent,
      nonce,
      verifier,
      returnTo,
      ttlSeconds: AUTH_LIMITS.transaction,
    });
    const location = new URL(discovery.authorization_endpoint);
    location.search = new URLSearchParams({
      client_id: config.clientId,
      response_type: "code",
      scope: "openid profile email",
      redirect_uri: redirectUri,
      state,
      nonce,
      code_challenge: challenge,
      code_challenge_method: "S256",
    }).toString();
    const uiLocale =
      request.form?.ui_locales ?? request.url.searchParams.get("ui_locales");
    if (uiLocale === "en" || uiLocale === "zh-Hans")
      location.searchParams.set("ui_locales", uiLocale);
    if (requireFreshAuth) {
      location.searchParams.set("max_age", "0");
      location.searchParams.set("prompt", "login");
    }
    if (intent === "switch") {
      location.searchParams.set("prompt", "login");
      location.searchParams.set("pt_account_switch", "1");
    }
    return {
      status: intent === "switch" ? 303 : 302,
      location: location.href,
      setCookies: bound.setCookies,
    };
  }
  async function begin(request) {
    const authenticated = await resolve(request);
    if (authenticated)
      return {
        status: 303,
        location: new URL(
          safeAuthReturnTo(request.url.searchParams.get("returnTo"), fallback),
          config.publicOrigin,
        ).href,
        setCookies: [],
      };
    const discovery = await discover(Date.now() + AUTH_LIMITS.discovery);
    return beginWith(
      request,
      config.sessionPolicy?.mode === "enforce" &&
        config.sessionPolicy.management
        ? "reauth"
        : "continue",
      await binding(request, true),
      discovery,
    );
  }
  async function cancel(request) {
    const expectedContext = requireAuthMutation(request, config.publicOrigin);
    const bound = await binding(request, false);
    if (!bound) {
      if (expectedContext !== null)
        throw new AuthError("session_context_changed", "transaction", 409);
      return null;
    }
    const session = await resolve(request);
    if ((session?.contextId ?? null) !== expectedContext)
      throw new AuthError("session_context_changed", "transaction", 409);
    const result = await store.cancel({
      bindingHash: bound.bindingHash,
      expectedContext,
    });
    return { ...bound, ...result, currentContextId: null };
  }
  async function switchAccount(request) {
    requireAuthMutation(request, config.publicOrigin);
    const discovery = await discover(Date.now() + AUTH_LIMITS.discovery);
    const bound = (await cancel(request)) || (await binding(request, true));
    return beginWith(request, "switch", bound, discovery);
  }
  async function callback(request) {
    const started = Date.now();
    let tx;
    try {
      const bound = await binding(request, false),
        state = request.url.searchParams.get("state");
      if (!bound || !state || !/^[A-Za-z0-9_-]{43}$/.test(state))
        throw new AuthError("oidc_transaction_invalid");
      tx = await store.claim({
        stateHash: await secretHash(state),
        bindingHash: bound.bindingHash,
      });
      if(config.sessionPolicy?.mode === "enforce" && config.sessionPolicy.management && tx.requireFreshAuth !== true)
        throw new AuthError("auth_reauthentication_required","session",401);
      if (request.url.searchParams.has("error"))
        throw new AuthError("oidc_denied", "transaction", 401);
      const code = request.url.searchParams.get("code");
      if (!code) throw new AuthError("oidc_transaction_invalid");
      const deadline = Math.min(started + AUTH_LIMITS.callback, tx.deadline);
      tx = { ...tx, deadline };
      const discovery = await discover(deadline);
      const body = new URLSearchParams({
        grant_type: "authorization_code",
        client_id: config.clientId,
        redirect_uri: redirectUri,
        code,
        code_verifier: tx.verifier,
      });
      const headers = { "content-type": "application/x-www-form-urlencoded" };
      if (config.clientAuthentication?.method === "client_secret_post")
        body.set("client_secret", config.clientAuthentication.secret);
      else if (config.clientAuthentication?.method === "client_secret_basic")
        headers.authorization = `Basic ${btoa(`${encodeURIComponent(config.clientId)}:${encodeURIComponent(config.clientAuthentication.secret)}`)}`;
      else if (
        config.clientAuthentication?.method &&
        config.clientAuthentication.method !== "none"
      )
        throw new AuthError("auth_configuration_invalid", "configuration", 503);
      const tokens = await fetchJson(
        endpoint(discovery.token_endpoint),
        { method: "POST", body, headers },
        "token",
        deadline,
      );
      const payload = await verifyOidcIdentityToken({
        token: tokens.id_token,
        jwksUrl: endpoint(discovery.jwks_uri),
        issuer: config.issuer,
        clientId: config.clientId,
        nonce: tx.nonce,
        deadline,
        fetchImpl,
      });
      let sessionPolicy;
      if (config.sessionPolicy?.mode === "enforce") {
        try {
          sessionPolicy = verifiedSessionPolicy(payload);
          requireFreshAuthentication(payload, tx);
        } catch (error) {
          throw new AuthError(
            error.code ?? "auth_session_policy_invalid",
            "session",
            error.status ?? 401,
          );
        }
      } else if (config.sessionPolicy?.mode === "shadow") {
        try {
          verifiedSessionPolicy(payload);
        } catch {
          onFailure({
            event: "auth_policy_shadow_mismatch",
            appId: config.appId,
          });
        }
      }
      const remaining = Math.min(AUTH_LIMITS.access, deadline - Date.now());
      if (remaining <= 0)
        throw new AuthError("access_unavailable", "access", 503, true);
      const accessSignal = AbortSignal.timeout(remaining);
      const prepared = await withinSignal(
        application.prepareSession({
          identity: {
            issuer: payload.iss,
            subject: payload.sub,
            authTime: payload.auth_time,
            sessionPolicy,
          },
          tokens: {
            idToken: tokens.id_token,
            accessToken: tokens.access_token,
            refreshToken: tokens.refresh_token,
            expiresIn: tokens.expires_in,
          },
          signal: accessSignal,
        }),
        accessSignal,
      );
      const proof = randomSecret(),
        contextId = randomSecret(16);
      const result = await store.finalize({
        transaction: tx,
        contextId,
        proofHash: await secretHash(proof),
        prepared,
      });
      return {
        status: 303,
        location: new URL(tx.returnTo, config.publicOrigin).href,
        setCookies: [
          ...clearObservedProofCookies(request),
          authCookie(
            names.proof(result.contextId),
            proof,
            secure,
            result.persistenceMode === "session"
              ? undefined
              : result.maxAgeSeconds,
          ),
        ],
      };
    } catch (error) {
      if (tx)
        await store
          .fail({
            stateHash: tx.stateHash,
            claimToken: tx.claimToken,
            code:
              error instanceof AuthError ? error.code : "unexpected_auth_error",
          })
          .catch(() => {});
      onFailure(
        authFailureLog(config.appId, request, error, Date.now() - started),
      );
      return failure(request, error, tx?.returnTo);
    }
  }
  return {
    begin,
    callback,
    logout: async (request) => {
      await cancel(request);
    },
    switchAccount,
    touchIdentity,
    resolve,
    failure,
    names,
    bootstrap: (request) => binding(request, true),
    clearObservedProofCookies,
  };
}
