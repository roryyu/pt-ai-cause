export type BrowserLocation = {
  pathname: string;
  search?: string;
  hash?: string;
  replace(value: string): void;
};

export type LoginRedirectOptions = {
  loginPath?: string;
  returnTo?: string;
  location?: BrowserLocation;
  fallback?: string;
};

export type SessionActivityDocument = {
  readonly visibilityState: string;
  addEventListener(
    type: string,
    listener: (event: Event) => void,
    options?: AddEventListenerOptions | boolean,
  ): void;
  removeEventListener(
    type: string,
    listener: (event: Event) => void,
    options?: EventListenerOptions | boolean,
  ): void;
};

export type SessionActivityTrackerOptions = {
  onActivity: () => void | Promise<void>;
  minIntervalMs?: number;
  document?: SessionActivityDocument;
  now?: () => number;
  setTimeout?: (callback: () => void, delay: number) => unknown;
  clearTimeout?: (timer: unknown) => void;
};

export type SessionRecoveryState =
  "active" | "reauthenticating" | "waiting_for_visibility" | "recovery_failed";

export type SessionRecoveryDocument = Pick<
  SessionActivityDocument,
  "visibilityState" | "addEventListener" | "removeEventListener"
>;

export type SessionRecoveryBroadcastChannel = {
  postMessage(message: { type: "session_invalidated" | "session_restored"; at: number }): void;
  addEventListener?(type: "message", listener: (event: MessageEvent) => void): void;
  removeEventListener?(type: "message", listener: (event: MessageEvent) => void): void;
  onmessage?: ((event: MessageEvent) => void) | null;
  close?(): void;
};

export type SessionRecoveryControllerOptions = {
  appId: string;
  loginPath?: string;
  fallbackReturnTo?: string;
  onStateChange: (state: SessionRecoveryState) => void;
  onBeforeRedirect?: () => void;
  onStopBackgroundWork?: () => void;
  checkSession?: () => boolean | Promise<boolean>;
  location?: BrowserLocation;
  document?: SessionRecoveryDocument;
  createBroadcastChannel?: (name: string) => SessionRecoveryBroadcastChannel | null;
  redirectToLogin?: (options: LoginRedirectOptions) => boolean;
};

export type SessionRecoveryController = {
  handleAuthenticationFailure(value: unknown): boolean;
  markRestored(options?: { announce?: boolean }): void;
  markRecoveryFailed(): void;
  dispose(): void;
};

export function currentReturnTo(location?: BrowserLocation, fallback?: string): string;
export function buildLoginUrl(options?: LoginRedirectOptions): string;
export function isFinalAuthenticationFailure(value: unknown): boolean;
export function redirectToLoginOnce(options?: LoginRedirectOptions): boolean;
export function createSessionActivityTracker(options: SessionActivityTrackerOptions): {
  dispose(): void;
};
export function createSessionRecoveryController(
  options: SessionRecoveryControllerOptions,
): SessionRecoveryController;

export function createSessionContextClient(options: {
  appId: string;
  sessionPath?: string;
  fetchImpl?: typeof fetch;
  locationLike?: { href: string; origin: string };
  onChanged?: (snapshot: {
    authenticated: boolean;
    contextId: string | null;
    [key: string]: unknown;
  }) => void;
  onUnavailable?: (error: unknown) => void;
  createChannel?: (name: string) => any;
}): {
  fetch: typeof fetch;
  check(): Promise<{ authenticated: boolean; contextId: string | null; [key: string]: unknown }>;
  current():
    { authenticated: boolean; contextId: string | null; [key: string]: unknown } | undefined;
  announce(): void;
  dispose(): void;
};
export function authFailureMessage(code: string | null | undefined, locale?: string): string;
