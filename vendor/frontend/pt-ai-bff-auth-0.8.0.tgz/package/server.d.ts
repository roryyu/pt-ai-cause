export type HttpError = Error & { status: number; code: string; details?: unknown };
export type OidcClaims = Record<string, unknown> & {
  sub: string;
  email?: string | null;
  name?: string;
  preferred_username?: string;
};

export function randomToken(bytes?: number): string;
export function opaqueHash(value: string): string;
export function safeEqual(left: unknown, right: unknown): boolean;
export function parseCookies(header?: string): Record<string, string>;
export function sessionCookie(name: string, value: string, options?: { maxAgeSeconds?: number; secure?: boolean }): string;
export function clearCookie(name: string, options?: { secure?: boolean }): string;
export function sendJson(response: any, status: number, body: unknown, headers?: Record<string, unknown>): void;
export function sendText(response: any, status: number, body: string, contentType?: string, headers?: Record<string, unknown>): void;
export function redirect(response: any, location: string, headers?: Record<string, unknown>, status?: number): void;
export function readJson(request: AsyncIterable<Uint8Array>, options?: { limit?: number }): Promise<Record<string, unknown>>;
export function httpError(status: number, code: string, message: string, details?: unknown): HttpError;
export function handleHttpError(response: any, error: unknown, correlationId?: string): void;
export function requestContext(request: any): { correlationId: string };
export function normalizeReturnTo(
  value: unknown,
  fallback?: string,
  options?: { blockedPrefixes?: string[]; maxLength?: number },
): string;
export function requireSameOriginMutation(
  request: any,
  expectedOrigin: string,
  options?: { sessionCookieName?: string },
): void;

export function buildOidcEndSessionUrl(input: {
  publicIssuer: string;
  internalIssuer?: string;
  clientId: string;
  postLogoutRedirectUri: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}): Promise<string>;
