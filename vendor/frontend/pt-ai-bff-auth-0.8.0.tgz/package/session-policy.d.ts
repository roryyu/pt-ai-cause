export interface SessionPolicyConfig {
  mode: "legacy" | "shadow" | "enforce";
  management: boolean;
  idleSeconds: number;
  maxSeconds: number;
  rememberIdleSeconds: number;
  rememberMaxSeconds: number;
}
export interface VerifiedSessionPolicy {
  mode: "session" | "remember";
  issuerSessionId: string;
  cycleStartedAt: number;
  cycleExpiresAt: number;
}
export interface IdentitySessionInput {
  sid: string;
  subject: string;
  activity?: boolean;
  fresh?: boolean;
}
export class SessionPolicyError extends Error {
  code: string;
  status: number;
  constructor(code: string, status?: number);
}
export function loadSessionPolicyV1(
  env?: Record<string, unknown>,
  prefix?: string,
  management?: boolean,
): SessionPolicyConfig;
export function verifiedSessionPolicy(
  payload: Record<string, unknown>,
  now?: number,
): VerifiedSessionPolicy;
export function requireFreshAuthentication(
  payload: Record<string, unknown>,
  tx: object,
  now?: number,
): void;
export function sessionTerms(
  policy: SessionPolicyConfig,
  identity: { sessionPolicy?: VerifiedSessionPolicy; authTime?: number },
  now?: number,
): {
  expiresAt: Date;
  persistenceMode: "session" | "remember";
  idleSeconds: number;
};
export function sessionIdleSeconds(
  row: Record<string, unknown>,
  policy: SessionPolicyConfig,
  legacyIdleSeconds: number,
): number;
export function createIdentitySessionChecker(input: {
  issuer: string;
  clientId: string;
  clientSecret: string;
  fetchImpl?: typeof fetch;
  now?: () => number;
}): (
  input: IdentitySessionInput,
) => Promise<{ active: boolean; cycleExpiresAt?: number }>;
export const SESSION_POLICY_LIMITS: Readonly<Record<string, number>>;
