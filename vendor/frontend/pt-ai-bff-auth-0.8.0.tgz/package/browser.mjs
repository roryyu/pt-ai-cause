const DEFAULT_LOGIN_PATH = "/auth/login";
const DEFAULT_RETURN_TO = "/";
const SESSION_ACTIVITY_INTERVAL_MS = 60_000;
const SESSION_ACTIVITY_EVENTS = ["pointerdown", "touchstart", "keydown", "scroll"];
const SESSION_RECOVERY_CHANNEL_VERSION = "human-session:v1";

let loginRedirectStarted = false;

function normalizedPath(pathname) {
  const value = String(pathname || "/");
  return value.startsWith("/") ? value : `/${value}`;
}

function isAuthLoop(pathname, loginPath) {
  const path = normalizedPath(pathname).toLowerCase();
  const login = normalizedPath(loginPath).toLowerCase();
  const authRoot = login.slice(0, login.lastIndexOf("/") + 1);
  return path === login || (authRoot !== "/" && path.startsWith(authRoot));
}

function safeReturnTo(value, loginPath, fallback) {
  if (
    typeof value !== "string" ||
    value.length > 2_048 ||
    !value.startsWith("/") ||
    /[\\\u0000-\u001f\u007f]/.test(value) ||
    /^\/(?:%2f|%5c)/i.test(value)
  )
    return fallback;
  try {
    const base = new URL("http://return-to.invalid/");
    const target = new URL(value, base);
    if (target.origin !== base.origin || isAuthLoop(target.pathname, loginPath)) return fallback;
    return `${target.pathname}${target.search}${target.hash}`;
  } catch {
    return fallback;
  }
}

export function currentReturnTo(locationLike = globalThis.location, fallback = DEFAULT_RETURN_TO) {
  if (!locationLike) return fallback;
  const pathname = normalizedPath(locationLike.pathname);
  const search = String(locationLike.search || "");
  const hash = String(locationLike.hash || "");
  const value = `${pathname}${search}${hash}`;
  return safeReturnTo(value, DEFAULT_LOGIN_PATH, fallback);
}

export function buildLoginUrl({
  loginPath = DEFAULT_LOGIN_PATH,
  returnTo,
  location: locationLike = globalThis.location,
  fallback = DEFAULT_RETURN_TO,
} = {}) {
  const desired = typeof returnTo === "string" ? returnTo : currentReturnTo(locationLike, fallback);
  const normalizedReturnTo = safeReturnTo(desired, loginPath, fallback);
  const separator = loginPath.includes("?") ? "&" : "?";
  return `${loginPath}${separator}returnTo=${encodeURIComponent(normalizedReturnTo)}`;
}

export function isFinalAuthenticationFailure(value) {
  const status = Number(value?.status ?? value?.response?.status);
  if (status !== 401) return false;
  const code = value?.code ?? value?.error?.code ?? value?.body?.error?.code;
  if (code === undefined) return true;
  if (typeof code !== "string") return false;
  const normalizedCode = code.trim().toLowerCase();
  return normalizedCode === "authentication_required" || normalizedCode === "session_expired";
}

export function redirectToLoginOnce({
  loginPath = DEFAULT_LOGIN_PATH,
  returnTo,
  location: locationLike = globalThis.location,
  fallback = DEFAULT_RETURN_TO,
} = {}) {
  if (loginRedirectStarted || !locationLike || typeof locationLike.replace !== "function")
    return false;
  if (isAuthLoop(locationLike.pathname, loginPath)) return false;
  loginRedirectStarted = true;
  locationLike.replace(buildLoginUrl({ loginPath, returnTo, location: locationLike, fallback }));
  return true;
}

function isVisible(documentLike) {
  return !documentLike || documentLike.visibilityState === "visible";
}

function createDefaultBroadcastChannel(name) {
  if (typeof globalThis.BroadcastChannel !== "function") return null;
  return new globalThis.BroadcastChannel(name);
}

/**
 * Coordinates the browser response to a final BFF authentication failure.
 *
 * The controller intentionally owns no user interface, application data, or
 * credentials. Applications supply their own presentation and stop/restart
 * background work through callbacks. A hidden tab never starts OIDC; it waits
 * until visible and can optionally verify its session before redirecting.
 */
export function createSessionRecoveryController({
  appId,
  loginPath = DEFAULT_LOGIN_PATH,
  fallbackReturnTo = DEFAULT_RETURN_TO,
  onStateChange,
  onBeforeRedirect,
  onStopBackgroundWork,
  checkSession,
  location: locationLike = globalThis.location,
  document: documentLike = globalThis.document,
  createBroadcastChannel = createDefaultBroadcastChannel,
  redirectToLogin = redirectToLoginOnce,
} = {}) {
  if (typeof appId !== "string" || !/^[a-z0-9][a-z0-9-]{0,63}$/i.test(appId)) {
    throw new TypeError("appId must be a stable application identifier");
  }
  if (typeof onStateChange !== "function") throw new TypeError("onStateChange must be a function");
  if (onBeforeRedirect !== undefined && typeof onBeforeRedirect !== "function") {
    throw new TypeError("onBeforeRedirect must be a function");
  }
  if (onStopBackgroundWork !== undefined && typeof onStopBackgroundWork !== "function") {
    throw new TypeError("onStopBackgroundWork must be a function");
  }
  if (checkSession !== undefined && typeof checkSession !== "function") {
    throw new TypeError("checkSession must be a function");
  }
  if (typeof redirectToLogin !== "function")
    throw new TypeError("redirectToLogin must be a function");
  if (
    documentLike &&
    (typeof documentLike.addEventListener !== "function" ||
      typeof documentLike.removeEventListener !== "function")
  ) {
    throw new TypeError("document must support event listeners");
  }

  let disposed = false;
  let state = "active";
  let backgroundWorkStopped = false;
  let recoveryCheckStarted = false;
  let redirectStarted = false;
  let channel = null;

  const setState = (nextState) => {
    if (state === nextState) return;
    state = nextState;
    onStateChange(state);
  };

  const stopBackgroundWork = () => {
    if (backgroundWorkStopped) return;
    backgroundWorkStopped = true;
    onStopBackgroundWork?.();
  };

  const post = (type) => {
    try {
      channel?.postMessage({ type, at: Date.now() });
    } catch {
      // Cross-tab coordination is best-effort; it must never block local recovery.
    }
  };

  const startRedirect = () => {
    if (disposed) return false;
    if (!isVisible(documentLike)) {
      setState("waiting_for_visibility");
      return false;
    }
    if (redirectStarted) return false;
    redirectStarted = true;
    setState("reauthenticating");
    return redirectToLogin({ loginPath, fallback: fallbackReturnTo, location: locationLike });
  };

  const beginRecovery = ({ announce } = { announce: true }) => {
    if (disposed) return;
    stopBackgroundWork();
    if (state === "active") {
      setState("reauthenticating");
      onBeforeRedirect?.();
      if (announce) post("session_invalidated");
    }
    startRedirect();
  };

  const verifyWhenVisible = () => {
    if (disposed || state !== "waiting_for_visibility" || recoveryCheckStarted) return;
    recoveryCheckStarted = true;
    if (!checkSession) {
      startRedirect();
      return;
    }
    Promise.resolve()
      .then(checkSession)
      .then((authenticated) => {
        if (disposed) return;
        recoveryCheckStarted = false;
        if (authenticated) controller.markRestored();
        else startRedirect();
      })
      .catch(() => {
        if (!disposed) controller.markRecoveryFailed();
      });
  };

  const onVisibilityChange = () => {
    if (isVisible(documentLike)) verifyWhenVisible();
  };

  const onBroadcastMessage = (event) => {
    const message = event?.data;
    if (!message || typeof message !== "object") return;
    if (message.type === "session_invalidated") beginRecovery({ announce: false });
    if (message.type === "session_restored" && state !== "active") {
      Promise.resolve()
        .then(() => checkSession?.())
        .then((authenticated) => {
          if (disposed) return;
          if (authenticated) controller.markRestored({ announce: false });
          else controller.markRecoveryFailed();
        })
        .catch(() => {
          if (!disposed) controller.markRecoveryFailed();
        });
    }
  };

  if (documentLike) documentLike.addEventListener("visibilitychange", onVisibilityChange);
  try {
    channel = createBroadcastChannel(`pt-ai:${appId}:${SESSION_RECOVERY_CHANNEL_VERSION}`);
    if (channel && typeof channel.addEventListener === "function")
      channel.addEventListener("message", onBroadcastMessage);
    else if (channel && "onmessage" in channel) channel.onmessage = onBroadcastMessage;
  } catch {
    channel = null;
  }

  const controller = {
    handleAuthenticationFailure(value) {
      if (!isFinalAuthenticationFailure(value)) return false;
      beginRecovery();
      return true;
    },
    markRestored({ announce = true } = {}) {
      if (disposed) return;
      recoveryCheckStarted = false;
      backgroundWorkStopped = false;
      redirectStarted = false;
      setState("active");
      if (announce) post("session_restored");
    },
    markRecoveryFailed() {
      if (disposed) return;
      recoveryCheckStarted = false;
      setState("recovery_failed");
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      if (documentLike) documentLike.removeEventListener("visibilitychange", onVisibilityChange);
      try {
        if (channel && typeof channel.removeEventListener === "function")
          channel.removeEventListener("message", onBroadcastMessage);
        if (channel && typeof channel.close === "function") channel.close();
      } finally {
        channel = null;
      }
    },
  };

  onStateChange(state);
  return controller;
}

export function createSessionActivityTracker({
  onActivity,
  minIntervalMs = SESSION_ACTIVITY_INTERVAL_MS,
  document: documentLike = globalThis.document,
  now = Date.now,
  setTimeout: setTimeoutLike = globalThis.setTimeout,
  clearTimeout: clearTimeoutLike = globalThis.clearTimeout,
} = {}) {
  if (typeof onActivity !== "function") throw new TypeError("onActivity must be a function");
  if (
    !documentLike ||
    typeof documentLike.addEventListener !== "function" ||
    typeof documentLike.removeEventListener !== "function"
  ) {
    throw new TypeError("document must support event listeners");
  }
  if (!Number.isFinite(minIntervalMs) || minIntervalMs <= 0) {
    throw new TypeError("minIntervalMs must be a positive number");
  }

  let disposed = false;
  let lastReportedAt = Number.NEGATIVE_INFINITY;
  let trailingTimer = null;
  let pendingVisibleActivity = false;

  const clearTrailingTimer = () => {
    if (trailingTimer !== null) clearTimeoutLike(trailingTimer);
    trailingTimer = null;
  };

  const report = () => {
    if (disposed || !pendingVisibleActivity || documentLike.visibilityState !== "visible") return;
    pendingVisibleActivity = false;
    clearTrailingTimer();
    lastReportedAt = now();
    Promise.resolve()
      .then(onActivity)
      .catch(() => undefined);
  };

  const scheduleTrailing = () => {
    if (trailingTimer !== null) return;
    const delay = Math.max(0, minIntervalMs - (now() - lastReportedAt));
    trailingTimer = setTimeoutLike(() => {
      trailingTimer = null;
      report();
    }, delay);
  };

  const onTrustedActivity = (event) => {
    if (disposed || event?.isTrusted !== true || documentLike.visibilityState !== "visible") return;
    pendingVisibleActivity = true;
    if (now() - lastReportedAt >= minIntervalMs) report();
    else scheduleTrailing();
  };

  const onVisibilityChange = () => {
    if (documentLike.visibilityState === "visible") return;
    pendingVisibleActivity = false;
    clearTrailingTimer();
  };

  for (const eventName of SESSION_ACTIVITY_EVENTS) {
    documentLike.addEventListener(eventName, onTrustedActivity, { passive: true });
  }
  documentLike.addEventListener("visibilitychange", onVisibilityChange);

  return {
    dispose() {
      if (disposed) return;
      disposed = true;
      pendingVisibleActivity = false;
      clearTrailingTimer();
      for (const eventName of SESSION_ACTIVITY_EVENTS) {
        documentLike.removeEventListener(eventName, onTrustedActivity, { passive: true });
      }
      documentLike.removeEventListener("visibilitychange", onVisibilityChange);
    },
  };
}

/** Context fencing for same-origin personnel requests. No business replay. */
export function createSessionContextClient({
  appId,
  sessionPath = "/auth/session",
  fetchImpl = globalThis.fetch.bind(globalThis),
  locationLike = globalThis.location,
  onChanged = () => {},
  onUnavailable = () => {},
  createChannel = createDefaultBroadcastChannel,
}) {
  let blocked = false;
  let snapshot,
    pending,
    generation = 0,
    disposed = false;
  const inflight = new Set();
  const channel = createChannel(`pt-ai:${appId}:session-v2`);
  const changedError = () =>
    Object.assign(new Error("The signed-in account changed. Reload before continuing."), {
      status: 409,
      code: "session_context_changed",
    });
  const accept = (value) => {
    if (
      !value ||
      typeof value.authenticated !== "boolean" ||
      (value.authenticated && !/^[A-Za-z0-9_-]{22}$/.test(value.contextId))
    )
      throw new Error("Invalid session response");
    const next = value.authenticated ? value.contextId : null;
    const wasUnknown = snapshot === undefined;
    const previous = snapshot?.contextId ?? null;
    const changed = snapshot !== undefined && previous !== next;
    snapshot = { ...value, contextId: next };
    if (wasUnknown && value.authenticated) channel?.postMessage({ type: "session_changed" });
    if (changed) {
      blocked = true;
      generation++;
      for (const controller of inflight) controller.abort();
      onChanged(snapshot);
    }
    return snapshot;
  };
  const check = () => {
    if (disposed) return Promise.reject(new Error("Session client disposed"));
    if (!pending)
      pending = fetchImpl(sessionPath, {
        credentials: "same-origin",
        cache: "no-store",
        signal: AbortSignal.timeout(10000),
      })
        .then(async (response) => {
          if (!response.ok) throw new Error("Session check unavailable");
          return accept(await response.json());
        })
        .catch((error) => {
          onUnavailable(error);
          throw error;
        })
        .finally(() => {
          pending = null;
        });
    return pending;
  };
  const guardedFetch = async (input, init = {}) => {
    const url = new URL(
      typeof input === "string" || input instanceof URL ? input : input.url,
      locationLike.href,
    );
    if (
      url.origin !== locationLike.origin ||
      (!url.pathname.startsWith("/api/") && !url.pathname.startsWith("/auth/"))
    )
      return fetchImpl(input, init);
    if (url.pathname === sessionPath) {
      const response = await fetchImpl(input, { ...init, cache: "no-store" });
      if (response.ok) accept(await response.clone().json());
      return response;
    }
    if (/\/(?:login|callback)$/.test(url.pathname)) return fetchImpl(input, init);
    if (snapshot === undefined) await check();
    if (blocked) throw changedError();
    const sentGeneration = generation,
      contextId = snapshot.contextId;
    const controller = new AbortController();
    inflight.add(controller);
    const headers = new Headers(input instanceof Request ? input.headers : undefined);
    new Headers(init.headers).forEach((v, k) => headers.set(k, v));
    headers.set("X-PT-Session-Context", contextId ?? "none");
    if (typeof snapshot.csrfToken === "string") headers.set("x-csrf-token", snapshot.csrfToken);
    const signals = [
      controller.signal,
      init.signal ?? (input instanceof Request ? input.signal : undefined),
    ].filter(Boolean);
    try {
      const response = await fetchImpl(input, {
        ...init,
        headers,
        credentials: "same-origin",
        signal: AbortSignal.any(signals),
      });
      if (generation !== sentGeneration) throw changedError();
      if (
        response.status === 409 &&
        (
          await response
            .clone()
            .json()
            .catch(() => null)
        )?.error?.code === "session_context_changed"
      ) {
        await check();
        throw changedError();
      }
      if (/\/logout$/.test(url.pathname) && response.ok) {
        generation++;
        snapshot = { authenticated: false, contextId: null };
        blocked = true;
        inflight.delete(controller);
        for (const pendingController of inflight) pendingController.abort();
        channel?.postMessage({ type: "session_changed" });
        // Logout's own JSON acknowledgement belongs to the successful barrier.
        // Do not fence it with the generation that logout just invalidated.
        return response;
      }
      if ([204, 205, 304].includes(response.status) || (init.method ?? (input instanceof Request ? input.method : "GET")).toUpperCase() === "HEAD" || !response.body) {
        inflight.delete(controller);
        return response;
      }
      const reader = response.body.getReader();
      const body = new ReadableStream({
        async pull(output) {
          try {
            if (generation !== sentGeneration) {
              await reader.cancel();
              throw changedError();
            }
            const result = await reader.read();
            if (generation !== sentGeneration) {
              await reader.cancel();
              throw changedError();
            }
            if (result.done) {
              inflight.delete(controller);
              output.close();
            } else output.enqueue(result.value);
          } catch (error) {
            inflight.delete(controller);
            output.error(error);
          }
        },
        async cancel(reason) {
          inflight.delete(controller);
          controller.abort();
          await reader.cancel(reason);
        },
      });
      const fenced = new Response(body, {
        status: response.status,
        statusText: response.statusText,
        headers: response.headers,
      });
      Object.defineProperty(fenced, "url", { value: response.url });
      return fenced;
    } catch (error) {
      inflight.delete(controller);
      throw error;
    }
  };
  const onMessage = (event) => {
    if (event?.data?.type === "session_changed") void check().catch(() => {});
  };
  channel?.addEventListener?.("message", onMessage);
  return {
    fetch: guardedFetch,
    check,
    current: () => snapshot,
    announce: () => channel?.postMessage({ type: "session_changed" }),
    dispose() {
      disposed = true;
      channel?.removeEventListener?.("message", onMessage);
      channel?.close?.();
      for (const controller of inflight) controller.abort();
    },
  };
}

/** Stable authentication error semantics; applications still own their pages. */
export function authFailureMessage(code, locale = "zh-CN") {
  if (!code) return "";
  const en = String(locale).toLowerCase().startsWith("en");
  const messages = {
    oidc_denied: [
      "登录未完成，请重新登录或使用其他账号。",
      "Sign-in was not completed. Try again or use another account.",
    ],
    oidc_transaction_expired: [
      "登录请求已过期，请重新登录。",
      "The sign-in request expired. Sign in again.",
    ],
    login_state_changed: [
      "登录状态已更新，请确认当前账号后继续。",
      "The sign-in state changed. Check the current account before continuing.",
    ],
    login_in_progress: [
      "登录正在处理中，请检查当前登录状态。",
      "Sign-in is being processed. Check the current session.",
    ],
    account_disabled: [
      "当前账号不可用，请联系管理员。",
      "This account is unavailable. Contact an administrator.",
    ],
    entry_entitlement_required: [
      "当前账号没有此应用的访问权限。",
      "This account does not have access to this application.",
    ],
    native_role_required: [
      "当前账号没有所需的应用管理权限。",
      "This account does not have the required application administration role.",
    ],
    identity_unavailable: [
      "登录服务暂时不可用，请稍后重试。",
      "The sign-in service is temporarily unavailable. Try again later.",
    ],
    access_unavailable: [
      "暂时无法检查应用访问权限，请稍后重试。",
      "Application access could not be checked. Try again later.",
    ],
    identity_verification_failed: [
      "身份验证未通过，请重新登录；若仍失败，请联系管理员。",
      "Identity verification failed. Sign in again; contact an administrator if it persists.",
    ],
    login_failed: [
      "未能建立应用会话，请重试；若仍失败，请联系管理员。",
      "The application session could not be created. Try again; contact an administrator if it persists.",
    ],
  };
  return (messages[code] ?? messages.login_failed)[en ? 1 : 0];
}
