import type { AuthStore } from "./core.mjs";
export type SqlQuery = (
  sql: string,
  parameters?: unknown[],
) => Promise<{ rows: Record<string, any>[] }>;
export function browserAuthSchema(appId: string): string;
export function createSqlAuthStore<P, S extends object>(input: {
  appId: string;
  query: SqlQuery;
  transaction: <T>(
    operation: (query: SqlQuery) => Promise<T>,
    deadline?: number,
  ) => Promise<T>;
  session: {
    subject?(query: SqlQuery, reference: string): Promise<string | null>;
    create(
      query: SqlQuery,
      prepared: P,
    ): Promise<{
      sessionRef: string;
      expiresAt: Date | string;
      persistenceMode?: "session" | "remember";
    }>;
    revoke(query: SqlQuery, reference: string): Promise<void>;
    resolve(query: SqlQuery, reference: string): Promise<S | null>;
    auditLogout?(
      query: SqlQuery,
      bindingHash: string,
      contextId: string | null,
    ): Promise<void>;
  };
  protect?: (value: string) => string | Promise<string>;
  unprotect?: (value: string) => string | Promise<string>;
}): AuthStore<P, S> & { cleanup(): Promise<void> };
