// SQL mechanics only. Applications supply the connection/transaction owner and
// all business session/principal/audit operations. No driver or connection here.
import { AuthError, randomSecret, secretHash } from "./core.mjs";
const tableNames = (appId) => {
  if (!["access", "portal", "foundation", "creative", "cause"].includes(appId))
    throw new TypeError("Unknown application");
  return {
    b: `${appId}_auth_bindings`,
    t: `${appId}_auth_transactions`,
    c: `${appId}_auth_contexts`,
  };
};
export function browserAuthSchema(appId) {
  const { b, t, c } = tableNames(appId);
  return `CREATE TABLE IF NOT EXISTS ${b} (binding_hash text PRIMARY KEY, epoch bigint NOT NULL DEFAULT 0 CHECK(epoch>=0), current_context_id text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS ${t} (state_hash text PRIMARY KEY, binding_hash text NOT NULL REFERENCES ${b}(binding_hash), epoch bigint NOT NULL, intent text NOT NULL CHECK(intent IN ('continue','switch','reauth')), nonce_secret text, verifier_secret text, return_to text NOT NULL, require_fresh_auth boolean NOT NULL DEFAULT false, reauth_requested_at timestamptz, expected_subject text, status text NOT NULL CHECK(status IN ('pending','processing','succeeded','failed','expired','cancelled')), expires_at timestamptz NOT NULL, claim_hash text, processing_deadline timestamptz, failure_code text, result_context_id text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE ${t} ADD COLUMN IF NOT EXISTS require_fresh_auth boolean NOT NULL DEFAULT false;
ALTER TABLE ${t} ADD COLUMN IF NOT EXISTS reauth_requested_at timestamptz;
ALTER TABLE ${t} ADD COLUMN IF NOT EXISTS expected_subject text;
ALTER TABLE ${t} DROP CONSTRAINT IF EXISTS ${t}_intent_check;
ALTER TABLE ${t} ADD CONSTRAINT ${t}_intent_check CHECK(intent IN ('continue','switch','reauth'));
CREATE INDEX IF NOT EXISTS ${t}_binding_epoch ON ${t}(binding_hash,epoch,status);
CREATE INDEX IF NOT EXISTS ${t}_expiry ON ${t}(expires_at);
CREATE TABLE IF NOT EXISTS ${c} (context_id text PRIMARY KEY, binding_hash text NOT NULL REFERENCES ${b}(binding_hash), app_session_ref text NOT NULL UNIQUE, proof_hash text NOT NULL, expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), revoked_at timestamptz, UNIQUE(binding_hash,context_id));
CREATE INDEX IF NOT EXISTS ${c}_binding ON ${c}(binding_hash,revoked_at);`;
}
export function createSqlAuthStore({
  appId,
  query,
  transaction,
  session,
  protect = (value) => value,
  unprotect = (value) => value,
}) {
  const { b, t, c } = tableNames(appId);
  const bindingRow = (r) =>
    r && {
      bindingHash: r.binding_hash,
      epoch: String(r.epoch),
      currentContextId: r.current_context_id,
      createdAt: r.created_at,
    };
  const lock = async (q, hash) =>
    (await q(`SELECT * FROM ${b} WHERE binding_hash=$1 FOR UPDATE`, [hash]))
      .rows[0];
  const cancelTransactions = (q, hash) =>
    q(
      `UPDATE ${t} SET status='cancelled',nonce_secret=NULL,verifier_secret=NULL,claim_hash=NULL,updated_at=now() WHERE binding_hash=$1 AND status IN ('pending','processing')`,
      [hash],
    );
  const revokeCurrent = async (q, bound) => {
    if (!bound.current_context_id) return;
    const context = (
      await q(
        `SELECT * FROM ${c} WHERE context_id=$1 AND binding_hash=$2 FOR UPDATE`,
        [bound.current_context_id, bound.binding_hash],
      )
    ).rows[0];
    if (context) {
      await session.revoke(q, context.app_session_ref);
      await q(
        `UPDATE ${c} SET revoked_at=COALESCE(revoked_at,now()) WHERE context_id=$1`,
        [context.context_id],
      );
    }
  };
  return {
    expectedSubject: async (hash) => {
      const bound = await query(
        `SELECT current_context_id FROM ${b} WHERE binding_hash=$1`,
        [hash],
      );
      const id = bound.rows[0]?.current_context_id;
      if (!id) return null;
      const context = await query(
        `SELECT app_session_ref FROM ${c} WHERE binding_hash=$1 AND context_id=$2`,
        [hash, id],
      );
      if (!context.rows[0]) return null;
      if (!session.subject)
        throw new AuthError("auth_configuration_invalid", "configuration", 503);
      return session.subject(query, context.rows[0].app_session_ref);
    },
    getBinding: async (hash) =>
      bindingRow(
        (await query(`SELECT * FROM ${b} WHERE binding_hash=$1`, [hash]))
          .rows[0],
      ),
    createBinding: async (hash) =>
      bindingRow(
        (
          await query(`INSERT INTO ${b}(binding_hash) VALUES($1) RETURNING *`, [
            hash,
          ])
        ).rows[0],
      ),
    async createTransaction(input) {
      await query(
        `UPDATE ${t} SET status='expired',nonce_secret=NULL,verifier_secret=NULL,claim_hash=NULL,updated_at=now() WHERE (expires_at<=now() OR (status='processing' AND processing_deadline<=now())) AND status IN ('pending','processing')`,
      );
      await query(
        `DELETE FROM ${t} WHERE expires_at<now()-interval '10 minutes'`,
      );
      const nonce = await protect(input.nonce),
        verifier = await protect(input.verifier);
      await transaction(async (q) => {
        const bound = await lock(q, input.bindingHash);
        if (!bound || String(bound.epoch) !== input.epoch)
          throw new AuthError("oidc_transaction_cancelled", "transaction", 409);
        await q(
          `INSERT INTO ${t}(state_hash,binding_hash,epoch,intent,nonce_secret,verifier_secret,return_to,require_fresh_auth,reauth_requested_at,expected_subject,status,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'pending',now()+interval '10 minutes')`,
          [
            input.stateHash,
            input.bindingHash,
            input.epoch,
            input.intent,
            nonce,
            verifier,
            input.returnTo,
            input.requireFreshAuth ?? false,
            input.reauthRequestedAt ?? null,
            input.expectedSubject ?? null,
          ],
        );
      });
    },
    async claim({ stateHash, bindingHash }) {
      const claimToken = randomSecret(),
        claimHash = await secretHash(claimToken);
      const row = await transaction(async (q) => {
        const bound = await lock(q, bindingHash);
        const tx = (
          await q(
            `SELECT *,expires_at>clock_timestamp() AS fresh FROM ${t} WHERE state_hash=$1 AND binding_hash=$2 FOR UPDATE`,
            [stateHash, bindingHash],
          )
        ).rows[0];
        if (!bound || !tx) throw new AuthError("oidc_transaction_invalid");
        if (!tx.fresh) throw new AuthError("oidc_transaction_expired");
        if (String(tx.epoch) !== String(bound.epoch))
          throw new AuthError(
            "oidc_transaction_superseded",
            "transaction",
            409,
          );
        if (tx.status === "processing")
          throw new AuthError(
            "oidc_transaction_in_progress",
            "transaction",
            409,
          );
        if (tx.status !== "pending")
          throw new AuthError("oidc_transaction_cancelled", "transaction", 409);
        return (
          await q(
            `UPDATE ${t} SET status='processing',claim_hash=$2,processing_deadline=LEAST(expires_at,clock_timestamp()+interval '20 seconds'),updated_at=now() WHERE state_hash=$1 RETURNING *`,
            [stateHash, claimHash],
          )
        ).rows[0];
      });
      return {
        stateHash,
        bindingHash,
        epoch: String(row.epoch),
        claimToken,
        nonce: await unprotect(row.nonce_secret),
        verifier: await unprotect(row.verifier_secret),
        returnTo: row.return_to,
        intent: row.intent,
        requireFreshAuth: row.require_fresh_auth,
        reauthRequestedAt: row.reauth_requested_at,
        expectedSubject: row.expected_subject,
        deadline: new Date(row.processing_deadline).getTime(),
      };
    },
    async fail({ stateHash, claimToken, code }) {
      await query(
        `UPDATE ${t} SET status='failed',failure_code=$3,nonce_secret=NULL,verifier_secret=NULL,claim_hash=NULL,updated_at=now() WHERE state_hash=$1 AND claim_hash=$2 AND status='processing'`,
        [stateHash, await secretHash(claimToken), code],
      );
    },
    async finalize({ transaction: tx, contextId, proofHash, prepared }) {
      const claimHash = await secretHash(tx.claimToken);
      return transaction(async (q) => {
        const bound = await lock(q, tx.bindingHash);
        const row = (
          await q(
            `SELECT *,expires_at>clock_timestamp() AND processing_deadline>clock_timestamp() AND clock_timestamp()<to_timestamp($3::double precision/1000) AS fresh FROM ${t} WHERE state_hash=$1 AND binding_hash=$2 FOR UPDATE`,
            [tx.stateHash, tx.bindingHash, tx.deadline],
          )
        ).rows[0];
        if (
          !bound ||
          !row ||
          row.status !== "processing" ||
          row.claim_hash !== claimHash ||
          String(bound.epoch) !== tx.epoch ||
          String(row.epoch) !== tx.epoch
        )
          throw new AuthError("oidc_transaction_cancelled", "transaction", 409);
        if (!row.fresh) throw new AuthError("oidc_transaction_expired");
        await revokeCurrent(q, bound);
        const created = await session.create(q, prepared);
        await q(
          `INSERT INTO ${c}(context_id,binding_hash,app_session_ref,proof_hash,expires_at) VALUES($1,$2,$3,$4,$5)`,
          [
            contextId,
            tx.bindingHash,
            created.sessionRef,
            proofHash,
            created.expiresAt,
          ],
        );
        // Recheck actual wall clock after application work, not transaction-start now().
        const updated = await q(
          `UPDATE ${t} SET status='succeeded',result_context_id=$2,nonce_secret=NULL,verifier_secret=NULL,claim_hash=NULL,updated_at=now() WHERE state_hash=$1 AND expires_at>clock_timestamp() AND processing_deadline>clock_timestamp() AND clock_timestamp()<to_timestamp($3::double precision/1000) RETURNING state_hash`,
          [tx.stateHash, contextId, tx.deadline],
        );
        if (!updated.rows.length)
          throw new AuthError("oidc_transaction_expired");
        await q(
          `UPDATE ${b} SET current_context_id=$2,epoch=epoch+1,updated_at=now() WHERE binding_hash=$1`,
          [tx.bindingHash, contextId],
        );
        await cancelTransactions(q, tx.bindingHash);
        return {
          contextId,
          persistenceMode: created.persistenceMode,
          maxAgeSeconds: Math.max(
            0,
            Math.floor(
              (new Date(created.expiresAt).getTime() - Date.now()) / 1000,
            ),
          ),
        };
      }, tx.deadline);
    },
    async resolveSession({ bindingHash, contextId, proofHash }) {
      const row = (
        await query(
          `SELECT c.* FROM ${c} c JOIN ${b} b ON b.binding_hash=c.binding_hash AND b.current_context_id=c.context_id WHERE c.binding_hash=$1 AND c.context_id=$2 AND c.proof_hash=$3 AND c.revoked_at IS NULL AND c.expires_at>now()`,
          [bindingHash, contextId, proofHash],
        )
      ).rows[0];
      if (!row) return null;
      const resolved = await session.resolve(query, row.app_session_ref);
      return resolved
        ? {
            ...resolved,
            contextId,
            bindingHash,
            sessionRef: row.app_session_ref,
          }
        : null;
    },
    async cancel({ bindingHash, expectedContext }) {
      return transaction(async (q) => {
        const bound = await lock(q, bindingHash);
        if (!bound)
          throw new AuthError("session_context_changed", "transaction", 409);
        let effective = null;
        if (bound.current_context_id) {
          const row = (
            await q(
              `SELECT * FROM ${c} WHERE context_id=$1 AND binding_hash=$2 AND revoked_at IS NULL AND expires_at>now()`,
              [bound.current_context_id, bindingHash],
            )
          ).rows[0];
          if (row && (await session.resolve(q, row.app_session_ref)))
            effective = row.context_id;
        }
        if (effective !== expectedContext)
          throw new AuthError("session_context_changed", "transaction", 409);
        await revokeCurrent(q, bound);
        await cancelTransactions(q, bindingHash);
        const row = (
          await q(
            `UPDATE ${b} SET current_context_id=NULL,epoch=epoch+1,updated_at=now() WHERE binding_hash=$1 RETURNING epoch`,
            [bindingHash],
          )
        ).rows[0];
        await session.auditLogout?.(q, bindingHash, effective);
        return { epoch: String(row.epoch) };
      });
    },
    async cleanup() {
      await query(
        `UPDATE ${t} SET status='expired',nonce_secret=NULL,verifier_secret=NULL,claim_hash=NULL,updated_at=now() WHERE (expires_at<=now() OR (status='processing' AND processing_deadline<=now())) AND status IN ('pending','processing')`,
      );
      await query(
        `DELETE FROM ${t} WHERE expires_at<now()-interval '10 minutes'`,
      );
    },
  };
}
