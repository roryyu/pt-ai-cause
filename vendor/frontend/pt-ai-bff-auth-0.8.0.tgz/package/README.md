# `@pt-ai/bff-auth`

> Version: v0.8.0

供五应用共同消费的最小认证与 HTTP 安全工具包。它只拥有无业务含义的 Cookie、同源校验、Authorization Code + PKCE OIDC 客户端、安全回跳、最终 401 判定、单次登录跳转、受信任的可见页面活跃事件规范化和 60 秒节流，以及最终认证失败后的无界面 Session 恢复协调。OIDC 启动仅支持由应用服务端显式选择的 `forceLogin` 布尔值，映射为固定 `prompt=login`。`buildOidcEndSessionUrl` 通过内部 Discovery 发现并验证浏览器可访问的退出端点，且只接受应用服务端构造的固定回跳地址。它不拥有 Identity 配置、人员权限、应用授权、Session 数据、草稿或业务路由，也不提供密码直登、Direct Access Grant、自动写操作重放或通用 UI。

独立仓库必须从 Workspace 的 `packages/releases/` 获取精确 TGZ，并在 `vendor/frontend/manifest.json` 固定来源提交、版本和 SHA-256。禁止通过相对路径读取 Workspace 源码。

```js
import { normalizeReturnTo, requireSameOriginMutation } from "@pt-ai/bff-auth/server";
import { createSessionActivityTracker, createSessionRecoveryController } from "@pt-ai/bff-auth/browser";

const activity = createSessionActivityTracker({
  onActivity: () => fetch("/auth/activity", { method: "POST", credentials: "same-origin", keepalive: true }),
});
// 应用卸载时调用 activity.dispose()。

const sessionRecovery = createSessionRecoveryController({
  appId: "portal",
  onStateChange: (state) => renderApplicationSessionState(state),
  onStopBackgroundWork: () => stopApplicationPolling(),
  onBeforeRedirect: () => persistExistingLocalDraftIfSafe(),
  checkSession: async () => (await fetch("/auth/session", { credentials: "same-origin" })).ok,
});
// API Client 遇到最终 401 时调用 sessionRecovery.handleAuthenticationFailure(error)。
// 应用卸载时调用 sessionRecovery.dispose()。
```

`createSessionRecoveryController` 只接受最终 401，先停止应用后台工作并通知应用显示恢复态；可见页面进行一次安全的 OIDC 跳转，隐藏页等到再次可见后才验证或跳转。它在同一应用的 tab 间通过 `BroadcastChannel` 交换不含身份、路由或业务数据的失效/恢复信号。应用必须自己决定 UI、草稿持久化、会话检查与恢复后重新拉取数据。

验证命令：

```bash
npm run build
npm test
```

OIDC 回调以通过签名、issuer、audience、nonce 和有效期校验的 Subject 识别身份；邮箱可缺省或为空，不作为登录前置条件。应用仍须通过 Access 校验账号状态和应用授权。

## v0.6 personnel authentication baseline

`./core` exports `createBrowserAuthCore`, typed failures, Cookie binding/proof rules and context validation. All four applications provide their own Session/Principal operations; the package never owns account permissions, database connections or business data. The previous `createOidcClient` and hand-written ID Token verifier are removed.

`./sql-store` contains the shared PostgreSQL transaction mechanics and schema generator. Applications supply a query function, transaction owner and Session create/revoke/resolve callbacks. No database driver or credentials are runtime dependencies. Creative invokes the same mechanics inside its existing authenticated gateway.

`./browser` adds `createSessionContextClient`: Session snapshots establish a non-secret context, requests carry that context, stale response bodies are rejected, and cross-tab hints trigger server checks rather than declaring authentication. No write is automatically replayed.

Protocol, adapter and deployment requirements are recorded in [the implementation contract](../../docs/architecture/PT-AI-四应用认证统一基线技术设计.md). PostgreSQL tests require an explicitly isolated `PT_AUTH_TEST_DATABASE_URL`; absence is a skip, not a database pass.

### Identity account-selection prerequisite

For PT AI Keycloak 26.7.0, `switchAccount` sends `prompt=login` plus `pt_account_switch=1`; ordinary `begin` never forwards either from an incoming URL. The matching Access-owned Identity Cookie SPI and registered-client opt-in are required to offer a different username without revoking other upstream sessions. The marker is intent, not identity or authorization. The native Identity password/MFA/required-action flow still authenticates the selected subject. Ship and verify the matching Identity integration before enabling this shared release in consumers; a redirect parameter alone is not account-switch acceptance.

The authentication UI may supply `ui_locales` as `en` or `zh-Hans` in its login URL or switch form. The core forwards only these two display hints; they do not affect identity, transaction ownership or authorization. Application locale persistence remains application-owned.

Bodyless HTTP responses (204/205/304 and HEAD) retain their native response object; context fencing must not attach a synthetic stream to them.

## 分层会话策略（0.7.0）

`./session-policy` 提供可信 pt_session 声明校验、固定周期夹限、管理再认证校验及服务端 Identity 状态客户端。`core` 的 sessionPolicy 配置使用 legacy/shadow/enforce；模式须由服务端配置，浏览器参数不能覆盖。应用依旧拥有 Session 与身份/权限数据。

Identity checker 需要受限服务客户端；有效状态最多缓存 60 秒，活动与写请求强制核对，不可达返回可重试 503。真实 PostgreSQL 事务测试使用显式 `PT_AUTH_TEST_DATABASE_URL` 隔离 schema；不要以跳过结果作为集成通过。

详见[分层会话技术设计](../../docs/architecture/PT-AI-分层会话超时与保持登录技术设计.md)。Cookie/SQL/interface 的更改需同步该契约。正式 TGZ 在源码验证并提交后由 Workspace pack 流程生成，测试中的临时 TGZ 不代表正式来源交付。

## Cause 接入（0.8.0）

`core` 和 `sql-store` 增加 appId=`cause`，使用独立的 Cookie 名及 `cause_auth_*` SQL 表。安全回跳同时排除 `/api/auth/*`，防止 Next.js 认证路由自循环。已有消费者可保留 0.7.0；新增 Cause 使用单包发布清单与精确 TGZ，不需要同步升级无改动的应用。
